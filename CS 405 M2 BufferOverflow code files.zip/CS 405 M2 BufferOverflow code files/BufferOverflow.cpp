// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO:
  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";

  // Use cin.get() to read input safely
  std::cin.get(user_input, 20); // Read up to 19 characters, leaving space for null terminator

  // Clear input buffer if there is extra input beyond 19 characters
  if (!std::cin.eof() && std::cin.peek() != '\n') {
      std::cin.clear();  // Reset error state
      std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discard excess characters
      std::cout << "Input too long! Only the first 19 characters were stored." << std::endl;
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
